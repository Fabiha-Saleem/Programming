


public class CinemaDemo {
    public static void main(String[] args) {

        
        CityCinema karachi = CityCinema.preloadCity("Karachi",
                new String[]{"Atrium Saddar", "Nueplex DHA"});

        System.out.println("=== CITY: Karachi | Cinema Management Demo ===");

        
        Cinema atrium = karachi.findCinemaByName("Atrium Saddar");
        Screen screen1 = atrium.findScreenByName("Screen-1");

  
        System.out.println("\n=== Initial Layout for Atrium Saddar Screen-1 ===");
        screen1.displayLayout();

   
        System.out.println("\nBooking seat 3-007...");
        boolean booked = screen1.book("3-007");
        System.out.println("Booking success: " + booked);
        screen1.displayLayout();

        System.out.println("\nAttempting double booking for 3-007...");
        boolean bookedAgain = screen1.book("3-007");
        System.out.println("Booking success: " + bookedAgain);
        screen1.displayLayout();

	System.out.println("\n=== FINAL UPDATED STATE ===");
        System.out.println(atrium);
	screen1.displayLayout();

       
        System.out.println("\nCanceling booking for 3-007...");
        boolean canceled = screen1.cancel("3-007");
        System.out.println("Cancel success: " + canceled);
        screen1.displayLayout();
      
        System.out.println("\n=== FINAL UPDATED STATE ===");
        System.out.println(atrium);
	screen1.displayLayout();
    }
}
