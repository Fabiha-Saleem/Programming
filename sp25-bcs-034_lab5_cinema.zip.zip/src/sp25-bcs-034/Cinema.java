public class Cinema {
    private String name;
    private Screen[] screens;
    private int size;

    public Cinema(String name, int initialCapacity) {
        this.name = name;
        this.screens = new Screen[Math.max(1, initialCapacity)];
        this.size = 0;
    }

    public Cinema(String name) { this(name, 3); }

    public String getName() { return name; }

    public void addScreen(Screen s) {
        if (size == screens.length) {
            Screen[] ns = new Screen[screens.length * 2];
            for (int i = 0; i < screens.length; i++) ns[i] = screens[i];
            screens = ns;
        }
        screens[size++] = s;
    }

    public Screen findScreenByName(String n) {
        for (int i = 0; i < size; i++)
            if (screens[i].getScreenName().equalsIgnoreCase(n))
                return screens[i];
        return null;
    }

    public Screen findScreenByIndex(int idx) {
        if (idx < 0 || idx >= size) return null;
        return screens[idx];
    }

    public boolean book(String screenName, String seatId) {
        Screen s = findScreenByName(screenName);
        return s != null && s.book(seatId);
    }

    public boolean cancel(String screenName, String seatId) {
        Screen s = findScreenByName(screenName);
        return s != null && s.cancel(seatId);
    }

    public int totalSeats() {
        int sum = 0;
        for (int i = 0; i < size; i++)
            sum += screens[i].getTotalSeatCount();
        return sum;
    }

    public int availableSeats() {
        int sum = 0;
        for (int i = 0; i < size; i++)
            sum += screens[i].getAvailableSeatCount();
        return sum;
    }

    public String toString() {
        return String.format("%s | screens=%d | totalSeats=%d | available=%d",
                name, size, totalSeats(), availableSeats());
    }

  public void printCompactAllScreens() {
    System.out.println("=== CINEMA: " + name + " | Layouts ===");
    for (int i = 0; i < size; i++) {
        screens[i].displayLayout();
    }
}

}
